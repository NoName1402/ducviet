package service;

import model.SinhVien;
import java.sql.Connection;

public class SinhVienServiceImpl implements SinhVienService {

    private Connection conn = ConnectionProvider.getConnection();

    @Override
    public boolean add(SinhVien sinhVien) {
        String sql = "INSERT ...";

        try {
            // Build Statement from the Connection...

            // Execute sql...
            return true;
        } catch (Exception ex) {
            ex.printStackTrace();

            return false;
        }
    }

    @Override
    public boolean update(SinhVien sinhVien) {
        return false;
    }

    @Override
    public boolean delete(SinhVien sinhVien) {
        return false;
    }

}
