package service;

import model.SinhVien;

public interface SinhVienService {

    public boolean add(SinhVien sinhVien);

    public boolean update(SinhVien sinhVien);

    public boolean delete(SinhVien sinhVien);

}
