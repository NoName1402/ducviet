package service;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConnectionProvider {

    private static final String DB_SERVER = "localhost";
    private static final String DB_NAME = "PTPM_FINALLY_JAVA_SOF203";
    private static final String DB_USERNAME = "sa";
    private static final String DB_PASSWORD = "12345678";

    private static Connection conn;

    private ConnectionProvider() {
    }

    public static Connection getConnection() {
        if (conn != null) {
            return conn;
        }

        try {
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");

            String strConn = String.format("jdbc:sqlserver://%s;DatabaseName=%s;TrustServerCertificate=true;",
                    DB_SERVER, DB_NAME);
            conn = DriverManager.getConnection(strConn, DB_USERNAME, DB_PASSWORD);
        } catch (ClassNotFoundException | SQLException ex) {
            ex.printStackTrace();
            conn = null;
        }

        return conn;
    }

    public void closeConnection() {
        //...
    }

}
